#!/usr/bin/env python3
"""Remove test-only source trees from a partial Soong module list."""

from __future__ import annotations

import argparse
from pathlib import Path


TEST_COMPONENTS = {
    "benchmarks",
    "cts",
    "fuzzer",
    "fuzzers",
    "test",
    "tests",
    "vts",
}
PRUNED_FILES = {
    "art/dexdump/Android.bp",
    "bootable/recovery/minadbd/Android.bp",
    "build/make/tools/zipalign/Android.bp",
    "device/google/cuttlefish/build/Android.bp",
    "external/e2fsprogs/debugfs/Android.bp",
    "prebuilts/rust-toolchain/linux-musl-x86/Android.bp",
    "prebuilts/rust-toolchain/linux-x86/Android.bp",
    "external/clspv/Android.bp",
    "external/clvk/Android.bp",
    "frameworks/base/ravenwood/Android.bp",
    "frameworks/base/services/incremental/Android.bp",
    "frameworks/base/media/jni/Android.bp",
    "frameworks/native/services/usbauthservice/Android.bp",
    "frameworks/native/services/aisealhostservice/Android.bp",
    "frameworks/native/services/serialservice/Android.bp",
    "frameworks/native/cmds/servicemanager/rpc_servicemanager/Android.bp",
    "frameworks/native/cmds/dumpstate/Android.bp",
    "hardware/interfaces/identity/aidl/default/Android.bp",
    "hardware/interfaces/identity/support/Android.bp",
    "hardware/interfaces/bluetooth/audio/utils/Android.bp",
    "hardware/interfaces/security/keymint/support/wrapped_key/Android.bp",
    "hardware/interfaces/security/secretkeeper/default/Android.bp",
    "hardware/interfaces/sensors/aidl/multihal/Android.bp",
    "hardware/interfaces/security/authgraph/default/Android.bp",
    "hardware/interfaces/compatibility_matrices/Android.bp",
    "system/core/fastboot/Android.bp",
    "system/core/gatekeeperd/Android.bp",
    "system/core/debuggerd/crasher/Android.bp",
    "system/apex/tools/Android.bp",
    "system/extras/mtectrl/Android.bp",
    "system/extras/kcmdlinectrl/Android.bp",
    "system/extras/profcollectd/libprofcollectd/Android.bp",
    "system/extras/squashfs_utils/Android.bp",
    "tools/platform-compat/java/android/compat/annotation/Android.bp",
}
PRUNED_PREFIXES = (
    "bootable/recovery/",
    "build/make/target/product/gsi/",
    "build/make/target/product/generic/",
    "build/make/tools/otatools_package/",
    "development/",
    "developers/build/",
    "external/bcc/",
    "frameworks/av/services/audioflinger/",
    "frameworks/av/services/audiopolicy/",
    "frameworks/av/media/audioserver/",
    "frameworks/av/media/codec2/hal/",
    "frameworks/av/media/codec2/components/",
    "frameworks/av/media/codec2/faultinjection/",
    "frameworks/av/media/codec2/vndk/",
    "frameworks/av/media/codec2/",
    "frameworks/av/media/mediaserver/",
    "frameworks/av/cmds/stagefright/",
    "frameworks/av/cmds/screenrecord/",
    "frameworks/av/camera/cameraserver/",
    "frameworks/av/camera/ndk/",
    "frameworks/av/media/mediacodeclist_generator/",
    "frameworks/av/media/libstagefright/",
    "frameworks/av/media/libdatasource/",
    "frameworks/av/media/libmediaplayerservice/",
    "frameworks/av/media/ndk/",
    "frameworks/av/media/module/codecserviceregistrant/",
    "frameworks/av/media/module/libapexcodecs/",
    "frameworks/av/media/module/libmediaformatshaper/",
    "frameworks/av/media/module/libmediatranscoding/",
    "frameworks/av/media/module/service.mediatranscoding/",
    "frameworks/av/media/module/codecs/",
    "frameworks/av/media/module/id3/",
    "frameworks/av/media/module/extractors/",
    "frameworks/av/services/mediacodec/",
    "frameworks/av/services/camera/virtualcamera/",
    "frameworks/av/services/camera/libcameraservice/",
    "frameworks/av/services/mediaextractor/",
    "frameworks/base/media/jni/",
    "frameworks/base/libs/native_activity_thread/",
    "frameworks/base/media/mca/",
    "frameworks/base/services/",
    "frameworks/native/services/gpuservice/",
    "frameworks/native/libs/cputimeinstate/",
    "hardware/interfaces/bluetooth/",
    "hardware/interfaces/virtualization/",
    "frameworks/base/cmds/app_process/",
    "prebuilts/vndk/",
    "packages/modules/Connectivity/",
    "packages/modules/Bluetooth/",
    "packages/modules/DnsResolver/",
    "packages/modules/NetworkStack/",
    "system/fs/fs_mgr/libsnapshot/",
    "system/bpf/",
    "system/core/libnetutils/",
    "system/libhidl/vintfdata/",
    "system/netd/",
    "system/server_configurable_flags/aconfigd/",
    "system/extras/partition_tools/",
    "system/extras/kcmdlinemodprobe/",
    "system/extras/profcollectd/",
    "system/extras/simpleperf/",
    "system/extras/verity/",
    "system/update_engine/",
    "system/vold/",
    "toolchain/pgo-profiles/sampling/",
)
REQUIRED_FILES = {
    "system/core/debuggerd/Android.bp",
    "system/tools/aidl/build/Android.bp",
    "hardware/interfaces/broadcastradio/aidl/Android.bp",
    "hardware/interfaces/oemlock/aidl/Android.bp",
    "hardware/interfaces/power/aidl/Android.bp",
    "hardware/interfaces/rebootescrow/aidl/Android.bp",
    "hardware/interfaces/thermal/aidl/Android.bp",
    "hardware/interfaces/usb/aidl/Android.bp",
    "hardware/interfaces/wifi/supplicant/aidl/Android.bp",
    "prebuilts/ndk/Android.bp",
    "prebuilts/rust-toolchain/linux-arm64/Android.bp",
    "packages/modules/Connectivity/bpf/headers/Android.bp",
    "packages/modules/Connectivity/bpf/syscall_wrappers/Android.bp",
    "frameworks/av/media/libstagefright/Android.bp",
    "frameworks/av/media/ndk/Android.bp",
    "frameworks/base/services/backup/Android.bp",
    "frameworks/base/services/core/java/com/android/server/display/feature/Android.bp",
    "frameworks/native/headers/Android.bp",
    "external/libchrome/soong/Android.bp",
    "external/rust/android-crates-io/crates/protobuf-codegen/Android.bp",
    "external/rust/android-crates-io/crates/protobuf-parse/Android.bp",
    "external/rust/android-crates-io/crates/which/Android.bp",
    "external/rust/android-crates-io/crates/bindgen-cli/Android.bp",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("module_list", type=Path)
    args = parser.parse_args()

    entries = sorted(REQUIRED_FILES | {
        line.strip()
        for line in args.module_list.read_text(encoding="utf-8").splitlines()
        if line.strip()
    })
    retained = [
        entry
        for entry in entries
        if TEST_COMPONENTS.isdisjoint(Path(entry).parts)
        and not (
            entry.startswith("hardware/interfaces/")
            and (
                "/default/" in entry
                or any("example" in part for part in Path(entry).parts)
            )
        )
        and (
            entry == "system/sepolicy/Android.bp"
            or not entry.startswith("system/sepolicy/")
        )
        and (entry in REQUIRED_FILES or not entry.startswith(PRUNED_PREFIXES))
        and entry not in PRUNED_FILES
    ]
    args.module_list.write_text("\n".join(retained) + "\n", encoding="utf-8")
    print(f"before={len(entries)} after={len(retained)} removed={len(entries) - len(retained)}")


if __name__ == "__main__":
    main()
