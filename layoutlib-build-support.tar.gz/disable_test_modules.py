#!/usr/bin/env python3
"""Remove test, fuzz, and benchmark modules from an Android.bp file."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from filter_android_bp import IDENTIFIER, block_end
from strip_module_target import disable_target_stanza


TYPE_MARKER = re.compile(r"test|fuzz|benchmark", re.IGNORECASE)
NON_NATIVE_TYPE = re.compile(
    r"(?:^|_)(?:java|python)(?:_|$)|^android_(?:app|library)(?:_|$)|droidstubs"
    r"|^(?:apex|(?:custom_)?platform_bootclasspath|(?:boot|systemserver)classpath_fragment|(?:override_)?runtime_resource_overlay|module_exports|sdk)$"
    r"|^generate_mojom_",
    re.IGNORECASE,
)
NAME_MARKER = re.compile(
    r"(?:^|[-_.])(?:cts|vts|g?tests?(?:[0-9]+)?|testing|testonly|fuzz(?:er|ers|ing)?|benchmarks?|lfi)"
    r"(?:$|[-_.])",
    re.IGNORECASE,
)
NAME = re.compile(r'\bname\s*:\s*"([^"]+)"')
DEFAULTS = re.compile(r"\bdefaults\s*:\s*\[([^\]]*)\]", re.DOTALL)
QUOTED = re.compile(r'"([^"]+)"')
BUILD_INCLUDE = re.compile(r"(?m)^\s*build\s*=")
SDK_VERSION = re.compile(r'(?m)^[ \t]*sdk_version\s*:\s*"[^"]+",[ \t]*\n')
HOST_SUPPORTED = re.compile(r"\bhost_supported\s*:\s*true\b")
NATIVE_BUILD_TOOLS = {
    "aidl_rust_glue",
    "SPIRV-Tools_utils_generate_registry_tables_py",
    "SPIRV-Tools_utils_ggt_py",
    "SPIRV-Tools_utils_generate_language_headers_py",
    "SPIRV-Tools_utils_update_build_version_py",
    "conv_linker_config",
    "generate-version-script",
    "generate_operator_out",
    "genfunctosyscallnrs",
    "genseccomp",
    "gensyscalls",
    "fs_config_generator",
    "jni_generator",
    "jni_registration_generator",
    "libprotobuf-python",
    "linker_config_proto",
    "merge_json",
    "mojom_bindings_generator",
    "mojom_generate_type_mappings",
    "perfetto_src_trace_processor_perfetto_sql_intrinsics_functions_tables_binary",
    "perfetto_src_trace_processor_perfetto_sql_intrinsics_table_functions_tables_binary",
    "perfetto_src_trace_processor_tables_tables_python_binary",
    "py-six",
    "py3-stdlib-prebuilt",
    "stats-log-api-gen",
    "transform_arm64_to_x86_64",
}
REQUIRED_HOST_FALLBACKS = {
    "camera_platform_flags_c_lib_for_test",
    "libaidlmetadata",
    "libring-test",
    "libstatspull-fake",
    "libstatssocket-fake",
    "perfetto_src_shared_lib_for_testing",
}
EXCLUDED_NATIVE_MODULES = {
    "GeneratedPolicyMetadata",
    "PolicyMetadataGenerator",
    "PolicyMetadataGeneratorHostLibrary",
    "TfliteNnapiDelegateTests_static",
    "applied_backported_fixes",
    "applied_backported_fix_binpbs",
    "all_aconfig_declarations",
    "aconfigd-system",
    "android_native_app_glue",
    "android.system.suspend-service",
    "android-non-updatable-stub-sources",
    "art-check-release-apex-gen-fakebin",
    "art_module_api_files",
    "art_boot_images",
    "android.hardware.sensors@2.X-shared-utils",
    "assemble_vintf",
    "bpfloader",
    "bootanimation",
    "charger",
    "charger_defaults",
    "checkvintf",
    "crash_dump",
    "cpplint-art-all",
    "cur_sdkinfo_src",
    "current_sdkinfo",
    "current-androidx-api",
    "debuggerd",
    "dex_bootjars",
    "com.android.hardware.wifi.rc",
    "framework-platform-compat-config",
    "framework-private-proguard",
    "framework-minus-apex-aconfig-srcjars",
    "framework-javastream-protos",
    "framework-non-updatable-sources",
    "framework-core-sources",
    "framework-wifi-non-updatable-sources",
    "font_fallback.xml",
    "gsid",
    "incidentd",
    "init",
    "init_first_stage",
    "init_second_stage",
    "init_second_stage.recovery",
    "init_system",
    "init_vendor",
    "gatekeeperd",
    "gen-android.hardware.wifi.rc",
    "generate_font_fallback",
    "libassemblevintf",
    "libandroid",
    "libandroid_net",
    "libandroid_preapex",
    "libaudioprocessing",
    "libaudioaidlranges",
    "libfs_mgr.microdroid",
    "libframework-connectivity-jni",
    "libframework-connectivity-tiramisu-jni",
    "libfilterfw",
    "libfilterfw_jni",
    "libhwui_static",
    "libclang_rt.hwasan",
    "libclang_rt.hwasan_static",
    "libc_malloc_debug",
    "libgmock_main_ndk",
    "libgmock_ndk",
    "libgtest_main_ndk_c++",
    "libgtest_ndk_c++",
    "libhealthd_draw",
    "libhealthd_charger_ui",
    "libhealthd_charger_ui-V1",
    "libhealthd_charger",
    "libhealthd_charger_nops",
    "libhealth2impl",
    "libhapticgeneratoraidl",
    "libkeymint_remote_prov_support",
    "libkeymint_wrapped_key_support",
    "libskqp_jni",
    "libskqp_jni_alltests",
    "libinit",
    "jemalloc5_unittests_gtestified_srcs",
    "jemalloc5_integrationtests_gtestified_srcs",
    "libcore-platform-compat-config",
    "libdebuggerd",
    "libdebuggerd_handler",
    "libdebuggerd_handler_core",
    "libdebuggerd_handler_fallback",
    "libbluetooth_hal_channel_avoidance",
    "libbluetooth_hal_ccc",
    "libbluetooth_hal_ext",
    "libbluetooth_hal_finder",
    "libbluetooth_hal_lmp_event",
    "libbluetooth_hal_ranging-V1",
    "libbluetooth_hal_ranging-V2",
    "libbluetooth_hal_sar",
    "libcamera_metadata_asserts",
    "libmojo",
    "libmediametricsservice",
    "libmedia_ndkformatpriv",
    "libmedia_midiiowrapper",
    "libmediaparser-jni",
    "libperfetto_android_internal",
    "libpreprocessingaidl",
    "libprefetch_rs",
    "librs_jni",
    "libreverbaidl",
    "libservices.core",
    "libsensorservicehidl",
    "libstagefright_foundation_colorutils_ndk",
    "libsensorservice",
    "libwebrtc",
    "logd",
    "linker",
    "linker.recovery",
    "mediametrics",
    "mime.types.minimized",
    "mime.types.minimized-alt",
    "non-updatable-exportable-current.txt",
    "non-updatable-exportable-removed.txt",
    "permission-versions",
    "permission-versions.xml",
    "prefetch",
    "remount",
    "replay_render_buffer",
    "sensorservice",
    "system-build.prop",
    "sdk_llvm-rs-cc",
    "validate_framework_keymaps",
    "validate_input_devices_keymaps",
    "vintffm",
}
SDK_VARIANT_MODULES = {
    "android_native_app_glue",
    "bionic_libc_platform_headers",
    "libbinder_ndk",
    "libbinder_headers_platform_shared_ndk",
    "libc",
    "libc++",
    "libc++-ndk-default",
    "libc_headers",
    "libc_uapi_headers",
    "libdl",
    "liblog",
    "libm",
    "libstdc++",
    "linux_bionic_supported",
    "libunwind-android-default",
    "ndk_system",
}


def uses_test_defaults(block: str) -> bool:
    return any(
        "non-test" not in dependency.lower() and NAME_MARKER.search(dependency)
        for values in DEFAULTS.findall(block)
        for dependency in QUOTED.findall(values)
    )


def has_build_module(text: str) -> bool:
    if BUILD_INCLUDE.search(text):
        return True
    line_start = 0
    metadata = {"license", "package", "soong_namespace"}
    while line_start < len(text):
        match = IDENTIFIER.match(text, line_start)
        if match:
            after = match.end()
            while after < len(text) and text[after] in " \t":
                after += 1
            if after < len(text) and text[after] == "{":
                if match.group() not in metadata:
                    return True
                line_start = block_end(text, after)
                continue
        newline = text.find("\n", line_start)
        line_start = len(text) if newline < 0 else newline + 1
    return False


def transform(text: str) -> tuple[str, bool]:
    output: list[str] = []
    cursor = 0
    line_start = 0
    changed = False

    while line_start < len(text):
        match = IDENTIFIER.match(text, line_start)
        if match:
            after = match.end()
            while after < len(text) and text[after] in " \t":
                after += 1
            if after < len(text) and text[after] == "{":
                end = block_end(text, after)
                block = text[line_start:end]
                name = NAME.search(block)
                module_type = match.group()
                module_name = name.group(1) if name is not None else ""
                preserve_named_test = module_type in {
                    "aconfig_value_set",
                    "aconfig_values",
                    "bootstrap_go_package",
                }
                preserve_build_tool = module_name in NATIVE_BUILD_TOOLS
                preserve_host_fallback = module_name in REQUIRED_HOST_FALLBACKS
                remove = "gtestified" in module_name or "hwasan" in module_name or (("nostd" in module_name or "no_std" in module_name) and not module_type.endswith("_defaults")) or module_name.endswith(("-compat-config", ".ndk")) or (module_name.startswith("art-check-") and module_name.endswith("-fakebin")) or module_name.startswith(("libandroid_logger", "libaudiohal@", "libaudiohal.effect@", "non-updatable-exportable-")) or module_name in EXCLUDED_NATIVE_MODULES or (
                    not preserve_host_fallback
                    and (
                        TYPE_MARKER.search(module_type)
                        or (NON_NATIVE_TYPE.search(module_type) and not preserve_build_tool)
                        or (
                            not preserve_named_test
                            and "non-test" not in module_name.lower()
                            and (
                                module_name.lower().startswith("libtest")
                                or NAME_MARKER.search(module_name)
                            )
                        )
                        or uses_test_defaults(block)
                        or "aidlaudioeffectservice_defaults" in block
                    )
                )
                if remove:
                    output.append(text[cursor:line_start])
                    while end < len(text) and text[end] in " \t\r\n":
                        end += 1
                    cursor = end
                    line_start = end
                    changed = True
                    continue
                if module_type.startswith(("cc_", "llvm_", "rust_")) and module_name not in SDK_VARIANT_MODULES:
                    native_block = SDK_VERSION.sub("", block)
                    if module_name == "rust_static_std":
                        native_block = re.sub(
                            r'(musl_arm64\s*:\s*\{.*?whole_static_libs\s*:\s*\[\s*)"libstd"',
                            r'\1"prebuilt_libstd"',
                            native_block,
                            count=1,
                            flags=re.DOTALL,
                        )
                    if module_type == "rust_stdlib_prebuilt_host":
                        native_block = native_block.replace("{", "{\n    prefer: true,", 1)
                    if HOST_SUPPORTED.search(native_block) or module_type.endswith("_host") or module_type == "rust_proc_macro" or module_type.startswith("rust_toolchain_"):
                        native_block = disable_target_stanza(native_block, "android")
                    if module_type.startswith("rust_"):
                        native_block = disable_target_stanza(native_block, "windows")
                    if module_type.startswith("rust_toolchain_"):
                        native_block = disable_target_stanza(native_block, "musl_arm64")
                    if native_block != block:
                        output.append(text[cursor:line_start])
                        output.append(native_block)
                        cursor = end
                        changed = True
                line_start = end
                continue
        newline = text.find("\n", line_start)
        line_start = len(text) if newline < 0 else newline + 1

    output.append(text[cursor:])
    transformed = "".join(output)
    if changed and transformed.strip() and not has_build_module(transformed):
        transformed = ""
    return transformed, changed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    updated, _ = transform(args.source.read_text(encoding="utf-8"))
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    args.destination.write_text(updated, encoding="utf-8")


if __name__ == "__main__":
    main()
