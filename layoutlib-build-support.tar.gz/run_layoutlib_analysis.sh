#!/bin/bash
set -euo pipefail

attempt=${1:?usage: run_layoutlib_analysis.sh ATTEMPT}
mode=${2:-analysis}
root=/GitHub/ika/android17-layoutlib
src=$root/src
name=android17-layoutlib-analysis-$attempt

python3 - "$src/out-android17-partial/soong/soong.aosp_arm64.variables" \
  "$src/out-android17-partial/soong/soong.environment.available" <<'PY'
import json
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as stream:
    variables = json.load(stream)
variables["Unbundled_build"] = True
variables["Allow_missing_dependencies"] = True
variables["HostMusl"] = False
variables["PartitionVarsForSoongMigrationOnlyDoNotUse"][
    "EnforceArtifactPathRequirements"
] = "false"
with open(path, "w", encoding="utf-8") as stream:
    json.dump(variables, stream, indent=4)
    stream.write("\n")

path = sys.argv[2]
with open(path, encoding="utf-8") as stream:
    environment = json.load(stream)
environment = [item for item in environment if item["Key"] != "RUST_PREBUILTS_VERSION"]
environment.append({"Key": "RUST_PREBUILTS_VERSION", "Value": "1.88.0"})
with open(path, "w", encoding="utf-8") as stream:
    json.dump(sorted(environment, key=lambda item: item["Key"]), stream, indent=4)
    stream.write("\n")
PY

python3 "$root/disable_test_modules.py" \
  "$src/prebuilts/rust-toolchain/linux-x86/Android.bp" \
  "$root/rust-toolchain.Android.bp.native"

mounts=(
  -v "$src:/src"
  -v "$root/arm64-prebuilts/prebuilts/rust/linux-arm64:/src/prebuilts/rust-toolchain/linux-arm64:ro"
  -v "$root/rust-toolchain.Android.bp.native:/src/prebuilts/rust-toolchain/linux-arm64/Android.bp:ro"
  -v "$root/libcore.Android.bp.native:/src/libcore/Android.bp:ro"
  -v "$root/libcore.ojluni.Android.bp.native:/src/libcore/ojluni/src/main/Android.bp:ro"
  -v "$root/aconfig.Android.bp.native:/src/build/make/tools/aconfig/aconfig/Android.bp:ro"
  -v "$root/art-build.Android.bp.native:/src/art/build/Android.bp:ro"
  -v "$root/art-flags.Android.bp.native:/src/art/build/flags/Android.bp:ro"
  -v "$root/protobuf.Android.bp.native:/src/external/protobuf/Android.bp:ro"
  -v "$root/aconfig-flags.Android.bp.native:/src/build/make/tools/aconfig/aconfig_flags/Android.bp:ro"
  -v "$root/logcat.Android.bp.native:/src/system/logging/logcat/Android.bp:ro"
  -v "$root/framework-base-proto.Android.bp.native:/src/frameworks/base/proto/Android.bp:ro"
  -v "$root/framework-base-ProtoLibraries.bp.native:/src/frameworks/base/ProtoLibraries.bp:ro"
  -v "$root/framework-base.Android.bp.native2:/src/frameworks/base/Android.bp:ro"
  -v "$root/timestatsproto.Android.bp.native:/src/frameworks/native/services/surfaceflinger/TimeStats/timestatsproto/Android.bp:ro"
  -v "$root/apex-proto.Android.bp.native:/src/system/apex/proto/Android.bp:ro"
  -v "$root/debuggerd-proto.Android.bp.native:/src/system/core/debuggerd/proto/Android.bp:ro"
  -v "$root/aconfig-storage-read.Android.bp.native:/src/build/make/tools/aconfig/aconfig_storage_read_api/Android.bp:ro"
  -v "$root/aconfig-protos.Android.bp.native:/src/build/make/tools/aconfig/aconfig_protos/Android.bp:ro"
  -v "$root/layoutlib.Android.bp.native:/src/frameworks/layoutlib/Android.bp:ro"
  -v "$root/adb.Android.bp.native:/src/packages/modules/adb/Android.bp:ro"
  -v "$root/framework-core-java.Android.bp.native:/src/frameworks/base/core/java/Android.bp:ro"
  -v "$root/framework-media.Android.bp.native:/src/frameworks/base/media/Android.bp:ro"
  -v "$root/aconfig-device-paths.Android.bp.native:/src/build/make/tools/aconfig/aconfig_device_paths/Android.bp:ro"
  -v "$root/brotli.Android.bp.native:/src/external/brotli/Android.bp:ro"
  -v "$root/graphics-proto.Android.bp.native:/src/frameworks/base/graphics/proto/Android.bp:ro"
  -v "$root/hidl-base.Android.bp.native:/src/system/libhidl/transport/base/1.0/Android.bp:ro"
  -v "$root/release-config-proto.Android.bp.native:/src/build/soong/cmd/release_config/release_config_proto/Android.bp:ro"
  -v "$root/sysprop.Android.bp.native:/src/system/tools/sysprop/Android.bp:ro"
  -v "$root/PlatformProperties.Android.bp.native:/src/system/libsysprop/srcs/Android.bp:ro"
  -v "$root/angle.Android.bp.native:/src/external/angle/Android.bp:ro"
  -v "$root/framework-AconfigFlags.bp.native:/src/frameworks/base/AconfigFlags.bp:ro"
  -v "$root/av-media-aconfig.Android.bp.native:/src/frameworks/av/media/aconfig/Android.bp:ro"
  -v "$root/av-audio-aconfig.Android.bp.native:/src/frameworks/av/media/audio/aconfig/Android.bp:ro"
  -v "$root/av-extractors.Android.bp.native:/src/frameworks/av/media/module/extractors/Android.bp:ro"
  -v "$root/libvulkan.Android.bp.native:/src/frameworks/native/vulkan/libvulkan/Android.bp:ro"
  -v "$root/aconfig-storage-file.Android.bp.native:/src/build/make/tools/aconfig/aconfig_storage_file/Android.bp:ro"
  -v "$root/drm-aidl.Android.bp.native:/src/hardware/interfaces/drm/aidl/Android.bp:ro"
  -v "$root/drm-common-aidl.Android.bp.native:/src/hardware/interfaces/drm/common/aidl/Android.bp:ro"
  -v "$root/binder-fuzzer-defaults.Android.bp.native:/src/frameworks/native/libs/binder/tests/Android.bp:ro"
  -v "$root/binder-rust-fuzzer-defaults.Android.bp.native:/src/frameworks/native/libs/binder/rust/tests/parcel_fuzzer/Android.bp:ro"
  -v "$root/boot-control-defaults.Android.bp.native:/src/hardware/interfaces/boot/1.1/default/boot_control/Android.bp:ro"
  -v "$root/libchrome-gestures.Android.bp.native:/src/external/libchrome-gestures/Android.bp:ro"
  -v "$root/libaudiopermission.Android.bp.native:/src/frameworks/av/media/libaudiopermission/Android.bp:ro"
  -v "$root/once_cell.Android.bp.native:/src/external/rust/android-crates-io/crates/once_cell/Android.bp:ro"
  -v "$root/ryu.Android.bp.native:/src/external/rust/android-crates-io/crates/ryu/Android.bp:ro"
  -v "$root/itoa.Android.bp.native:/src/external/rust/android-crates-io/crates/itoa/Android.bp:ro"
  -v "$root/unicode-bidi.Android.bp.native:/src/external/rust/android-crates-io/crates/unicode-bidi/Android.bp:ro"
  -v "$root/anyhow.Android.bp.native:/src/external/rust/android-crates-io/crates/anyhow/Android.bp:ro"
  -v "$root/tinytemplate.Android.bp.native:/src/external/rust/android-crates-io/crates/tinytemplate/Android.bp:ro"
  -v "$root/bytes.Android.bp.native:/src/external/rust/android-crates-io/crates/bytes/Android.bp:ro"
  -v "$root/icu-root.Android.bp.native:/src/external/icu/Android.bp:ro"
  -v "$root/jemalloc.Android.bp.native:/src/external/jemalloc_new/Android.bp:ro"
  -v "$root/convert-finalized-flags.Android.bp.native:/src/build/make/tools/aconfig/convert_finalized_flags/Android.bp:ro"
  -v "$root/spin.Android.bp.native:/src/external/rust/android-crates-io/crates/spin/Android.bp:ro"
  -v "$root/aho-corasick.Android.bp.native:/src/external/rust/android-crates-io/crates/aho-corasick/Android.bp:ro"
  -v "$root/libdexfile.Android.bp.headers:/src/art/libdexfile/Android.bp:ro"
  -v "$root/uuid.Android.bp.native:/src/external/rust/android-crates-io/crates/uuid/Android.bp:ro"
  -v "$root/libstatssocket.Android.bp.native:/src/packages/modules/StatsD/lib/libstatssocket/Android.bp:ro"
  -v "$root/statsd-flags.Android.bp.native:/src/packages/modules/StatsD/flags/Android.bp:ro"
  -v "$root/statsd-apex.Android.bp.native:/src/packages/modules/StatsD/apex/Android.bp:ro"
  -v "$root/libcore-NativeCode.bp.native:/src/libcore/NativeCode.bp:ro"
  -v "$root/binder.Android.bp.native:/src/frameworks/native/libs/binder/Android.bp:ro"
  -v "$root/libbase.Android.bp.native:/src/system/libbase/Android.bp:ro"
  -v "$root/libhealthloop.Android.bp.native:/src/hardware/interfaces/health/utils/libhealthloop/Android.bp:ro"
  -v "$root/avb.Android.bp.native:/src/external/avb/Android.bp:ro"
  -v "$root/scudo.Android.bp.native:/src/external/scudo/Android.bp:ro"
  -v "$root/debuggerd.Android.bp.native:/src/system/core/debuggerd/Android.bp:ro"
  -v "$root/art-cmdline.Android.bp.native:/src/art/cmdline/Android.bp:ro"
  -v "$root/conscrypt-apex.Android.bp.native:/src/external/conscrypt/apex/Android.bp:ro"
  -v "$root/init.Android.bp.native:/src/system/core/init/Android.bp:ro"
  -v "$root/art-odrefresh.Android.bp.native:/src/art/odrefresh/Android.bp:ro"
  -v "$root/art-libnativeloader.Android.bp.native:/src/art/libnativeloader/Android.bp:ro"
  -v "$root/modules-utils-java.Android.bp.native:/src/frameworks/libs/modules-utils/java/Android.bp:ro"
  -v "$root/services-usb.Android.bp.native:/src/frameworks/base/services/usb/Android.bp:ro"
  -v "$root/art-dexdump.Android.bp.native:/src/art/dexdump/Android.bp:ro"
  -v "$root/art-hiddenapi.Android.bp.native:/src/art/tools/hiddenapi/Android.bp:ro"
  -v "$root/art-disassembler.Android.bp.native:/src/art/disassembler/Android.bp:ro"
  -v "$root/art-libprofile.Android.bp.native:/src/art/libprofile/Android.bp:ro"
  -v "$root/art-libarttools.Android.bp.native:/src/art/libarttools/Android.bp:ro"
  -v "$root/art-sigchainlib.Android.bp.native:/src/art/sigchainlib/Android.bp:ro"
  -v "$root/art-libartbase.Android.bp.native:/src/art/libartbase/Android.bp:ro"
  -v "$root/art-compiler.Android.bp.native:/src/art/compiler/Android.bp:ro"
  -v "$root/art-libartpalette.Android.bp.native:/src/art/libartpalette/Android.bp:ro"
  -v "$root/art-runtime.Android.bp.native:/src/art/runtime/Android.bp:ro"
  -v "$root/graphics-mapper-stable-c.Android.bp.native:/src/hardware/interfaces/graphics/mapper/stable-c/Android.bp:ro"
  -v "$root/network-security-config.Android.bp.native:/src/frameworks/base/packages/NetworkSecurityConfig/Android.bp:ro"
  -v "$root/services-core.Android.bp.native:/src/frameworks/base/services/core/Android.bp:ro"
  -v "$root/art-dexoptanalyzer.Android.bp.native:/src/art/dexoptanalyzer/Android.bp:ro"
  -v "$root/art-dex2oat.Android.bp.native:/src/art/dex2oat/Android.bp:ro"
  -v "$root/art-simulator.Android.bp.native:/src/art/simulator/Android.bp:ro"
  -v "$root/art-signal-dumper.Android.bp.native:/src/art/tools/signal_dumper/Android.bp:ro"
  -v "$root/art-build-apex.Android.bp.native:/src/art/build/apex/Android.bp:ro"
  -v "$root/goldfish-build-tools.Android.bp.native:/src/device/generic/goldfish/build/tools/Android.bp:ro"
  -v "$root/sepolicy-contexts.Android.bp.native:/src/system/sepolicy/contexts/Android.bp:ro"
  -v "$root/stagefright-xmlparser.Android.bp.native:/src/frameworks/av/media/libstagefright/xmlparser/Android.bp:ro"
  -v "$root/streaming-proto.Android.bp.native:/src/frameworks/base/tools/streaming_proto/Android.bp:ro"
  -v "$root/lights-feature.Android.bp.native:/src/frameworks/base/services/core/java/com/android/server/lights/feature/Android.bp:ro"
  -v "$root/camera.Android.bp.native:/src/frameworks/av/camera/Android.bp:ro"
  -v "$root/releasetools.Android.bp.native:/src/build/make/tools/releasetools/Android.bp:ro"
  -v "$root/apexd.Android.bp.native:/src/system/apex/apexd/Android.bp:ro"
  -v "$root/art-ahat.Android.bp.native:/src/art/tools/ahat/Android.bp:ro"
  -v "$root/media-apex-framework.Android.bp.native:/src/packages/modules/Media/apex/framework/Android.bp:ro"
  -v "$root/healthd.Android.bp.native:/src/system/core/healthd/Android.bp:ro"
  -v "$root/permission-versioning.Android.bp.native:/src/build/make/tools/permission_versioning/Android.bp:ro"
  -v "$root/media-apex.Android.bp.native:/src/frameworks/av/apex/Android.bp:ro"
  -v "$root/hidl-safe-union.Android.bp.native:/src/system/libhidl/transport/safe_union/1.0/Android.bp:ro"
  -v "$root/bluetooth-audio-utils.Android.bp.native:/src/hardware/interfaces/bluetooth/audio/utils/Android.bp:ro"
  -v "$root/audio-capengine.Android.bp.native:/src/hardware/interfaces/audio/aidl/default/config/audioPolicy/capengine/Android.bp:ro"
  -v "$root/audio-7.1-config.Android.bp.native:/src/hardware/interfaces/audio/7.1/config/Android.bp:ro"
  -v "$root/sepolicy.Android.bp.native:/src/system/sepolicy/Android.bp:ro"
  -v "$root/sepolicy-mac-permissions.Android.bp.native:/src/system/sepolicy/mac_permissions/Android.bp:ro"
  -v "$root/framework-location.Android.bp.native:/src/frameworks/base/location/Android.bp:ro"
  -v "$root/aconfigd.Android.bp.native:/src/system/server_configurable_flags/aconfigd/Android.bp:ro"
  -v "$root/activity-manager.Android.bp.native:/src/frameworks/base/services/core/java/com/android/server/am/Android.bp:ro"
  -v "$root/suspend-default.Android.bp.native:/src/system/hardware/interfaces/suspend/aidl/default/Android.bp:ro"
  -v "$root/stagefright-headers.Android.bp.native:/src/frameworks/av/media/libstagefright/Android.bp:ro"
  -v "$root/media-ndk-headers.Android.bp.native:/src/frameworks/av/media/ndk/Android.bp:ro"
  -v "$root/native-media-headers.Android.bp.native:/src/frameworks/native/headers/Android.bp:ro"
  -v "$root/core-jni.Android.bp.native:/src/frameworks/base/core/jni/Android.bp:ro"
)

if [[ -f "$root/aidl-overlays.list" ]]; then
  while IFS='|' read -r overlay destination; do
    mounts+=(-v "$overlay:/src/$destination:ro")
  done < "$root/aidl-overlays.list"
fi

if [[ -f "$root/hidl-overlays.list" ]]; then
  while IFS='|' read -r overlay destination; do
    mounts+=(-v "$overlay:/src/$destination:ro")
  done < "$root/hidl-overlays.list"
fi

if [[ -f "$root/test-overlays.list" ]]; then
  while IFS='|' read -r overlay destination; do
    mounts+=(-v "$overlay:/src/$destination:ro")
  done < "$root/test-overlays.list"
fi

if [[ "$mode" == audit ]]; then
  run_command='prebuilts/build-tools/linux-arm64/bin/ninja -n -k0 -f layoutlib-build.ninja layoutlib_jni-linux_glibc_arm64_shared-install'
elif [[ "$mode" == build ]]; then
  run_command='prebuilts/build-tools/linux-arm64/bin/ninja -j6 -f layoutlib-build.ninja layoutlib_jni-linux_glibc_arm64_shared-install'
else
  run_command='TOP=/src out-android17-partial/host/linux-arm64/bin/soong_build \
    --top /src \
    --soong_out out-android17-partial/soong \
    --out out-android17-partial \
    --soong_variables out-android17-partial/soong/soong.aosp_arm64.variables \
    -o out-android17-partial/soong/build.aosp_arm64.ninja \
    --partial-analysis-targets=layoutlib_jni \
    --kati_suffix -aosp_arm64 \
    -l out-android17-partial/.module_paths/Android.bp.layoutlib.list \
    --available_env out-android17-partial/soong/soong.environment.available \
    --used_env out-android17-partial/soong/soong.environment.used.aosp_arm64.filtered \
    Android.bp'
fi

podman rm -f "$name" >/dev/null 2>&1 || true
podman run --name "$name" --network=none --security-opt label=disable -w /src \
  "${mounts[@]}" localhost/ika-debian13-arm64:layoutlib /bin/bash -lc "$run_command"
